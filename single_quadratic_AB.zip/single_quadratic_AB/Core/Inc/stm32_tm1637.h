#pragma once
//
//void tm1637Init(void);
//void tm1637DisplayDecimal(int v, int displaySeparator);
//void tm1637SetBrightness(char brightness);
//
//void tm1637Init_1(void);
//void tm1637DisplayDecimal_1(int v, int displaySeparator);
//void tm1637SetBrightness_1(char brightness);
//
//void tm1637Init_2(void);
//void tm1637DisplayDecimal_2(int v, int displaySeparator);
//void tm1637SetBrightness_2(char brightness);

void tm1637Init_3(void);
void tm1637DisplayDecimal_3(int v, int displaySeparator);
void tm1637SetBrightness_3(char brightness);
//
//void tm1637Init_4(void);
//void tm1637DisplayDecimal_4(int v, int displaySeparator);
//void tm1637SetBrightness_4(char brightness);
//
//void tm1637Init_5(void);
//void tm1637DisplayDecimal_5(int v, int displaySeparator);
//void tm1637SetBrightness_5(char brightness);
