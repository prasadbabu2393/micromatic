/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "stm32_tm1637.h"

#define ENCODER_A2 GPIO_PIN_2
#define ENCODER_B2 GPIO_PIN_3

#define BRAKE_STATUS_PIN GPIO_PIN_8
#define BRAKE_STATUS_PORT GPIOA
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
// Define the current state of the encoder

int currentStateA2 = 0;
int currentStateB2 = 0;

// Define the previous state of the encoder

int previousStateA2 = 0;
int previousStateB2 = 0;

// Define the count of pulses
uint8_t brakeStatus = 0;
int count2 = 0;
uint8_t mode =0;
uint32_t previousMillis = 0;
uint32_t debounceDelay = 0.1;
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART3_UART_Init();
  /* USER CODE BEGIN 2 */
  tm1637Init_3();
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	  uint8_t mybyte[5], rxbyte[1];

	  mybyte[0] = (count2>>24) & 0xFF;
	  mybyte[1] = (count2>>16) & 0xFF;
	  mybyte[2] = (count2>>8) & 0xFF;
	  mybyte[3] = (count2) & 0xFF;

	  if (HAL_GPIO_ReadPin(BRAKE_STATUS_PORT, BRAKE_STATUS_PIN) == GPIO_PIN_RESET) {
	  	 mybyte[4] = 0; // Brake is active/pressed
	  } else {
		 mybyte[4] = 1; // Brake is inactive/released
	  }
	  if(mode)
	  {
	  HAL_UART_Transmit(&huart3, mybyte, sizeof(mybyte), 1000);
	  }

	  if( HAL_UART_Receive(&huart3, &rxbyte, 1, 1000) == HAL_OK)
	  {
		  if (rxbyte[0] == 0) {
		  count2 = 0;  // Reset count if the received byte is 0Q
	      }
		  else if (rxbyte[0] == 1) {
		    	  mode = 1;
		  }
//		  else if (rxbyte[0] == 2) {
//
//			  if (HAL_GPIO_ReadPin(BRAKE_STATUS_PORT, BRAKE_STATUS_PIN) == GPIO_PIN_RESET) {
//			          brakeStatus = 0; // Brake is active/pressed
//			      } else {
//			          brakeStatus = 1; // Brake is inactive/released
//			      }
//			  HAL_UART_Transmit(&huart3, &brakeStatus, 1, 1000);
//		  }
	  }
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
  uint32_t currentMillis = HAL_GetTick();

  // Debouncing logic
  if (currentMillis - previousMillis < debounceDelay)
  {
    return;
  }
  previousMillis = currentMillis;

     if (GPIO_Pin == ENCODER_A2 || GPIO_Pin == ENCODER_B2)
    {
      // Read the current state of both channels
      currentStateA2 = HAL_GPIO_ReadPin(GPIOA, ENCODER_A2);
      currentStateB2 = HAL_GPIO_ReadPin(GPIOA, ENCODER_B2);

      // Determine the direction of rotation
      if ((previousStateA2 == 0 && previousStateB2 == 0 && currentStateA2 == 1) ||
          (previousStateA2 == 1 && previousStateB2 == 1 && currentStateA2 == 0))
      {
        // Clockwise
        count2++;
      }
      else if ((previousStateA2 == 0 && previousStateB2 == 0 && currentStateB2 == 1) ||
               (previousStateA2 == 1 && previousStateB2 == 1 && currentStateB2 == 0))
      {
        // Counterclockwise
        count2--;
      }

      // Save the current states as the previous states
      previousStateA2 = currentStateA2;
      previousStateB2 = currentStateB2;
    }
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
